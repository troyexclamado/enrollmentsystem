-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2022 at 08:53 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollmentsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccounts`
--

CREATE TABLE `tblaccounts` (
  `accountID` int(10) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `firstname` varchar(256) NOT NULL,
  `lastname` varchar(256) NOT NULL,
  `middlename` varchar(256) NOT NULL,
  `position` varchar(20) NOT NULL,
  `studentNumber` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblaccounts`
--

INSERT INTO `tblaccounts` (`accountID`, `email`, `password`, `firstname`, `lastname`, `middlename`, `position`, `studentNumber`) VALUES
(22001, 'sample@mail.com', 'password', 'JUAN', 'DELA CRUZ', 'FRANCISCO', 'STUDENT', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblbacksubjects`
--

CREATE TABLE `tblbacksubjects` (
  `backsubjectID` int(11) NOT NULL,
  `subjectCode` varchar(50) NOT NULL,
  `accountID` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblcoursedetails`
--

CREATE TABLE `tblcoursedetails` (
  `courseID` int(10) NOT NULL,
  `courseDescription` varchar(256) NOT NULL,
  `courseAbbr` varchar(10) NOT NULL,
  `year` int(1) NOT NULL,
  `section` varchar(2) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `semester` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcoursedetails`
--

INSERT INTO `tblcoursedetails` (`courseID`, `courseDescription`, `courseAbbr`, `year`, `section`, `schoolYear`, `semester`) VALUES
(1, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 1, 'A', '2021-2022', 2),
(2, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 1, 'B', '2021-2022', 2),
(3, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 1, 'C', '2021-2022', 2),
(4, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 2, 'A', '2021-2022', 2),
(5, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 2, 'B', '2021-2022', 2),
(6, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 2, 'C', '2021-2022', 2),
(7, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 3, 'A', '2021-2022', 2),
(8, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 3, 'B', '2021-2022', 2),
(9, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 3, 'C', '2021-2022', 2),
(10, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 4, 'A', '2021-2022', 2),
(11, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 4, 'B', '2021-2022', 2),
(12, 'BACHELOR OF SCIENCE IN COMPUTER SCIENCE', 'BSCS', 4, 'C', '2021-2022', 2),
(13, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 1, 'A', '2021-2022', 2),
(14, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 1, 'B', '2021-2022', 2),
(15, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 1, 'C', '2021-2022', 2),
(16, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 2, 'A', '2021-2022', 2),
(17, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 2, 'B', '2021-2022', 2),
(18, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 2, 'C', '2021-2022', 2),
(19, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 3, 'A', '2021-2022', 2),
(20, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 3, 'B', '2021-2022', 2),
(21, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 3, 'C', '2021-2022', 2),
(22, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 4, 'A', '2021-2022', 2),
(23, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 4, 'B', '2021-2022', 2),
(24, 'BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY', 'BSIT', 4, 'C', '2021-2022', 2),
(25, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 1, 'A', '2021-2022', 2),
(26, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 1, 'B', '2021-2022', 2),
(27, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 1, 'C', '2021-2022', 2),
(28, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 2, 'A', '2021-2022', 2),
(29, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 2, 'B', '2021-2022', 2),
(30, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 2, 'C', '2021-2022', 2),
(31, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 3, 'A', '2021-2022', 2),
(32, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 3, 'B', '2021-2022', 2),
(33, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 3, 'C', '2021-2022', 2),
(34, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 4, 'A', '2021-2022', 2),
(35, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 4, 'B', '2021-2022', 2),
(36, 'BACHELOR OF SCIENCE IN INFORMATION SYSTEM', 'BSIS', 4, 'C', '2021-2022', 2),
(37, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 1, 'A', '2021-2022', 2),
(38, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 1, 'B', '2021-2022', 2),
(39, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 1, 'C', '2021-2022', 2),
(40, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 2, 'A', '2021-2022', 2),
(41, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 2, 'B', '2021-2022', 2),
(42, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 2, 'C', '2021-2022', 2),
(43, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 3, 'A', '2021-2022', 2),
(44, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 3, 'B', '2021-2022', 2),
(45, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 3, 'C', '2021-2022', 2),
(46, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 4, 'A', '2021-2022', 2),
(47, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 4, 'B', '2021-2022', 2),
(48, 'BACHELOR OF SCIENCE IN ENTERTAINMENT AND MULTIMEDIA COMPUTING', 'BSEMC', 4, 'C', '2021-2022', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblenrolledsubjects`
--

CREATE TABLE `tblenrolledsubjects` (
  `studentNumber` int(8) NOT NULL,
  `subjectCode` varchar(10) NOT NULL,
  `scheduleID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblenrolledsubjects`
--

INSERT INTO `tblenrolledsubjects` (`studentNumber`, `subjectCode`, `scheduleID`) VALUES
(20220001, 'CCS 001', 1),
(20220001, 'CCS 002', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblmis`
--

CREATE TABLE `tblmis` (
  `MIS_ID` int(10) NOT NULL,
  `accountID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblprofessors`
--

CREATE TABLE `tblprofessors` (
  `professorID` int(10) NOT NULL,
  `accountID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblprofessorsubjects`
--

CREATE TABLE `tblprofessorsubjects` (
  `professorID` int(10) NOT NULL,
  `subjectCode` varchar(10) NOT NULL,
  `scheduleID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `accountID` int(10) NOT NULL,
  `studentNumber` int(8) NOT NULL,
  `address` varchar(512) NOT NULL,
  `birthday` date NOT NULL,
  `birthplace` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `contactNumber` varchar(256) NOT NULL,
  `courseID` int(10) NOT NULL,
  `section` varchar(5) NOT NULL,
  `enrollmentStatus` varchar(20) NOT NULL,
  `scheme` int(1) NOT NULL,
  `position` varchar(50) NOT NULL,
  `dateOfEnrollment` datetime NOT NULL,
  `MIS_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`accountID`, `studentNumber`, `address`, `birthday`, `birthplace`, `email`, `contactNumber`, `courseID`, `section`, `enrollmentStatus`, `scheme`, `position`, `dateOfEnrollment`, `MIS_ID`) VALUES
(22001, 20220001, 'CALOOCAN CITY', '2000-01-01', 'CALOOCAN CITY', 'sample@mail.com', '09123456789', 1, '', 'PENDING', 1, '', '2022-04-23 13:46:51', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudenttransactions`
--

CREATE TABLE `tblstudenttransactions` (
  `studentNumber` int(8) NOT NULL,
  `TF_OR` varchar(10) NOT NULL,
  `TF_AMOUNT` int(10) NOT NULL,
  `MF_OR` varchar(10) NOT NULL,
  `MF_AMOUNT` int(10) NOT NULL,
  `totalAmount` int(10) NOT NULL,
  `balance` int(10) NOT NULL,
  `penalty` int(10) NOT NULL,
  `TNC` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `subjectCode` varchar(10) NOT NULL,
  `subjectDescription` varchar(256) NOT NULL,
  `subjectUnits` int(1) NOT NULL,
  `courseID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsubjects`
--

INSERT INTO `tblsubjects` (`subjectCode`, `subjectDescription`, `subjectUnits`, `courseID`) VALUES
('CCS 001', 'INTRODUCTION TO PROGRAMMING', 3, 7),
('CCS 002', 'INTRODUCTION TO COMPUTING', 3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjectschedules`
--

CREATE TABLE `tblsubjectschedules` (
  `scheduleID` int(10) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `day` varchar(3) NOT NULL,
  `startTime` varchar(5) NOT NULL,
  `endTime` varchar(5) NOT NULL,
  `courseID` int(10) NOT NULL,
  `section` varchar(1) NOT NULL,
  `semester` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsubjectschedules`
--

INSERT INTO `tblsubjectschedules` (`scheduleID`, `subject`, `day`, `startTime`, `endTime`, `courseID`, `section`, `semester`) VALUES
(1, 'CCS 001', 'MON', '10:00', '13:00', 7, 'A', 2),
(2, 'CCS 002', 'TUE', '10:00', '13:00', 7, 'A', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaccounts`
--
ALTER TABLE `tblaccounts`
  ADD PRIMARY KEY (`accountID`);

--
-- Indexes for table `tblbacksubjects`
--
ALTER TABLE `tblbacksubjects`
  ADD PRIMARY KEY (`backsubjectID`);

--
-- Indexes for table `tblcoursedetails`
--
ALTER TABLE `tblcoursedetails`
  ADD PRIMARY KEY (`courseID`);

--
-- Indexes for table `tblmis`
--
ALTER TABLE `tblmis`
  ADD PRIMARY KEY (`MIS_ID`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`studentNumber`);

--
-- Indexes for table `tblsubjectschedules`
--
ALTER TABLE `tblsubjectschedules`
  ADD PRIMARY KEY (`scheduleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaccounts`
--
ALTER TABLE `tblaccounts`
  MODIFY `accountID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22002;

--
-- AUTO_INCREMENT for table `tblbacksubjects`
--
ALTER TABLE `tblbacksubjects`
  MODIFY `backsubjectID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcoursedetails`
--
ALTER TABLE `tblcoursedetails`
  MODIFY `courseID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tblmis`
--
ALTER TABLE `tblmis`
  MODIFY `MIS_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `studentNumber` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220002;

--
-- AUTO_INCREMENT for table `tblsubjectschedules`
--
ALTER TABLE `tblsubjectschedules`
  MODIFY `scheduleID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
