-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2022 at 09:10 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollmentsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `accountID` int(11) NOT NULL,
  `student_number` int(20) DEFAULT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `position` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `back_subjects`
--

CREATE TABLE `back_subjects` (
  `back_subjectID` int(11) NOT NULL,
  `accountNumber` varchar(50) NOT NULL,
  `subject_code` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseID` varchar(20) NOT NULL,
  `courseAbbr` varchar(10) NOT NULL,
  `courseName` varchar(256) NOT NULL,
  `courseYear` varchar(10) NOT NULL,
  `courseGroup` varchar(100) NOT NULL,
  `courseSubjects` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `enrolledstudents`
--

CREATE TABLE `enrolledstudents` (
  `studentNumber` varchar(8) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `birthplace` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `contactNumber` varchar(50) NOT NULL,
  `lastSchoolAttended` varchar(100) NOT NULL,
  `lastSchoolYearAttended` varchar(20) NOT NULL,
  `address` varchar(256) NOT NULL,
  `accountUsername` varchar(50) NOT NULL,
  `accountPassword` varchar(50) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` varchar(20) NOT NULL,
  `section` varchar(2) NOT NULL,
  `semester` varchar(5) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `preenrolledstudents`
--

CREATE TABLE `preenrolledstudents` (
  `pre_id` int(11) NOT NULL,
  `accountID` varchar(8) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `birthplace` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `contactNumber` varchar(50) NOT NULL,
  `address` varchar(256) NOT NULL,
  `lastSchoolAttended` varchar(100) NOT NULL,
  `lastSchoolYearAttended` varchar(20) NOT NULL,
  `lastSchoolAddress` varchar(256) NOT NULL,
  `accountUsername` varchar(50) NOT NULL,
  `accountPassword` varchar(50) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` varchar(20) NOT NULL,
  `section` varchar(2) NOT NULL,
  `semester` varchar(5) NOT NULL,
  `position` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subj_id` int(11) NOT NULL,
  `subjectCode` varchar(10) NOT NULL,
  `subjectName` varchar(50) NOT NULL,
  `subjectDescription` varchar(256) NOT NULL,
  `subjectPreRequisite` varchar(50) NOT NULL,
  `subjectProfessors` varchar(256) NOT NULL,
  `course` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subj_id`, `subjectCode`, `subjectName`, `subjectDescription`, `subjectPreRequisite`, `subjectProfessors`, `course`, `year`, `section`, `semester`) VALUES
(1, 'CS 107', 'EMBEDDED PROGRAMMING', '', '', '', 'BSCS', '3RD', '', '1ST'),
(2, 'CS 109', 'SOFTWARE ENGINEERING 2', '', '', '', 'BSCS', '3RD', '', '1ST'),
(3, 'CS 112', 'OPERATING SYSTEM', '', '', '', 'BSCS', '3RD', '', '1ST'),
(5, 'CS 101', 'VISUAL STUDIO', '', '', '', 'BSCS', '2ND', '', '1ST');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`accountID`);

--
-- Indexes for table `back_subjects`
--
ALTER TABLE `back_subjects`
  ADD PRIMARY KEY (`back_subjectID`);

--
-- Indexes for table `preenrolledstudents`
--
ALTER TABLE `preenrolledstudents`
  ADD PRIMARY KEY (`pre_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subj_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `accountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20220027;

--
-- AUTO_INCREMENT for table `back_subjects`
--
ALTER TABLE `back_subjects`
  MODIFY `back_subjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `preenrolledstudents`
--
ALTER TABLE `preenrolledstudents`
  MODIFY `pre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
